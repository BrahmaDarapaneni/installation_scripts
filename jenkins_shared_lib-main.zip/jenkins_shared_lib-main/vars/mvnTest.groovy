def call(){
    sh 'mvn test'
}