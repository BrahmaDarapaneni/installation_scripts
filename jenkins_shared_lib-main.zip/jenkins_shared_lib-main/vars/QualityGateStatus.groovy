

def call(credentialsId){

waitForQualityGate abortPipeline: false, credentialsId: credentialsId

}


