def call(){
    sh 'mvn clean install'
}